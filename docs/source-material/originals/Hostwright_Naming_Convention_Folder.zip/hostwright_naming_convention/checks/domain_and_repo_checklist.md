# Domain and Repo Checklist

Before declaring Hostwright canonical, complete this checklist manually.

## GitHub

- [ ] Check `github.com/hostwright`.
- [ ] Check `github.com/hostwright/hostwright`.
- [ ] Decide final org, for example `github.com/hostwright` or `github.com/d3v07/hostwright`.
- [ ] Create/reserve the repo.
- [ ] Add placeholder README if needed.

## Domain

Check registrar availability directly. Search results are not enough.

- [ ] `hostwright.dev`
- [ ] `hostwright.sh`
- [ ] `hostwright.io`
- [ ] `hostwright.cc`

Buy/reserve the first clean one from this order:

1. `hostwright.dev`
2. `hostwright.sh`
3. `hostwright.io`
4. `hostwright.cc`

## Package/tooling namespaces

- [ ] `brew search hostwright`
- [ ] Swift Package Index search for `hostwright`
- [ ] GitHub code search for `hostwright.yaml`
- [ ] GitHub code search for `hostwrightd`
- [ ] GHCR namespace check if container images will be published
- [ ] npm/PyPI/crates.io only if future packages are planned

## Approval

- [ ] User confirms final domain.
- [ ] User confirms final GitHub repo/org.
- [ ] Rename branch may begin.

