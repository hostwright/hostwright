# Collision Check Log

## Current candidate

**Hostwright**

## Checks already performed

| Check | Result | Confidence |
|---|---|---|
| Exact web search for `"Hostwright" GitHub` | No obvious indexed result found. | Medium |
| GitHub-focused search `site:github.com "Hostwright"` | No obvious indexed result found. | Medium |
| Exact indexed domain search for `hostwright.dev`, `hostwright.sh`, `hostwright.io`, `hostwright.cc` | No obvious indexed result found. | Medium |
| Local DNS-style resolution attempt for `hostwright.dev`, `hostwright.sh`, `hostwright.io`, `hostwright.cc` | No host records returned in local container check. | Low/medium |

## Checks still required by user in browser

Search-index checks are not the same as ownership checks. Before renaming all artifacts, perform actual checkout/reservation checks:

1. Open GitHub while logged in.
2. Check whether `github.com/hostwright` can be created or whether a clean organization/repo path is available.
3. Try creating/reserving `github.com/<chosen-org>/hostwright`.
4. Open Cloudflare Registrar, Porkbun, Namecheap, or Name.com.
5. Check and buy/reserve at least one of:
   - `hostwright.dev`
   - `hostwright.sh`
   - `hostwright.io`
   - `hostwright.cc`
6. Check Homebrew:
   ```bash
   brew search hostwright
   ```
7. Check Swift Package Index for `hostwright`.
8. Search package registries only if future distribution requires them:
   - npm
   - PyPI
   - crates.io
   - Docker Hub / GHCR namespace

## Blocked old name

`Orchard` is blocked for public use because OpenAI has a public `openai/orchard` repository described as an orchestrator for running Tart Virtual Machines on a cluster of Apple Silicon devices. It includes a `cmd/orchard` folder and usage with `orchard` CLI commands.

## Final status labels

Use these labels in planning docs:

| Label | Meaning |
|---|---|
| `candidate` | Name passed vibe/meaning review, but not ownership checks. |
| `pre-screened` | Name passed exact web/GitHub/domain-surface searches. |
| `reserved` | GitHub repo/org and domain are secured. |
| `canonical` | Name is locked and all docs/code should use it. |
| `blocked` | Name has a serious collision and must not be used publicly. |

Current Hostwright status: `pre-screened`, not yet `reserved`.

