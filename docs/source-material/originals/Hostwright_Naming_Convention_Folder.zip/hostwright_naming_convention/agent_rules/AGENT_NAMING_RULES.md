# Agent Naming Rules

## Mandatory behavior

Agents must not invent a new project name, CLI name, daemon name, manifest name, domain, package name, module name, or launchd label.

Use the canonical terms from `NAMING_CONVENTION.md`.

## Current state

Hostwright is the public-name candidate. It becomes canonical only after GitHub and domain ownership checks pass.

## Do not do this

- Do not rename existing research folders automatically.
- Do not mass-rename PDFs or DOCX files before ownership checks.
- Do not introduce shorthand command names.
- Do not use Orchard in public-facing files after final rename.
- Do not use botanical alternatives.
- Do not use Kubernetes/Docker-style names such as pod, kube, helm, dock, fleet, harbor, ship, or cluster unless a design document explicitly needs those terms as references.

## Required agent output after any naming-related change

Every naming-related PR must include:

1. Files changed.
2. Terms changed.
3. Old terms intentionally left, with reason.
4. Commands run.
5. Search command proving no accidental old public terms remain.
6. Human approval request if public identity changed.

