#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"

echo "Checking for blocked public Orchard terms under: $ROOT"

grep -RInE "\bOrchard\b|\borchard\b|orchardd|orchard\.yaml|orchard\.cc" "$ROOT" \
  --exclude-dir=.git \
  --exclude-dir=hostwright_naming_convention \
  --exclude='COLLISION_CHECK_LOG.md' \
  --exclude='RENAME_PLAYBOOK.md' \
  || true

echo "Review any matches above. Public-facing files should use Hostwright after canonical rename."
