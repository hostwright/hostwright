# Controlled Rename Playbook

This playbook is intentionally conservative. Existing Orchard documents should not be mass-renamed until final ownership checks pass.

## Phase 0: Freeze

Do not rename old PDFs, DOCX files, folders, diagrams, or existing research artifacts yet. They remain historical internal material.

## Phase 1: Ownership checks

Before any rename commit, verify:

| Check | Required result |
|---|---|
| GitHub org/user `hostwright` | Available or not needed because another org is chosen. |
| GitHub repo `<org>/hostwright` | Available. |
| Domain `hostwright.dev` | Buyable or already owned by user. |
| Backup domain | At least one of `hostwright.sh`, `hostwright.io`, `hostwright.cc` buyable or already owned. |
| Homebrew formula | No severe collision. |
| Swift Package Index | No severe collision. |
| npm/PyPI/crates.io | No severe collision if future package distribution touches those ecosystems. |
| Web exact search | No dominant infra/container/orchestrator/Apple Silicon collision. |

## Phase 2: Create a rename branch

```bash
git checkout -b chore/rename-hostwright
```

## Phase 3: Rename source terms

Only after checks pass, replace canonical terms:

| Old | New |
|---|---|
| Orchard | Hostwright |
| orchard | hostwright |
| orchardd | hostwrightd |
| orchard.yaml | hostwright.yaml |
| orchard.cc | hostwright.dev or selected owned domain |
| ORCHARD | HOSTWRIGHT |
| `com.orchard` | `com.hostwright` |
| `OrchardCLI` | `HostwrightCLI` |
| `OrchardDaemon` | `HostwrightDaemon` |
| `OrchardCore` | `HostwrightCore` |
| `OrchardRuntime` | `HostwrightRuntime` |
| `OrchardState` | `HostwrightState` |
| `OrchardReconciler` | `HostwrightReconciler` |

## Phase 4: Rename docs once

Rename final deliverables only once:

| Old artifact | New artifact |
|---|---|
| `Orchard_Agent_Engineering_Manual.*` | `Hostwright_Agent_Engineering_Manual.*` |
| `Orchard_Document_2_Security_and_Apple_Silicon_Acceleration.*` | `Hostwright_Document_2_Security_and_Apple_Silicon_Acceleration.*` |
| `Orchard_Document_3_Network_Tunnels_Protocols_Cloud_Security.*` | `Hostwright_Document_3_Network_Tunnels_Protocols_Cloud_Security.*` |
| `Orchard_Final_Production_Arsenal.*` | `Hostwright_Final_Production_Arsenal.*` |
| `Orchard_Agent_Arsenal_MD_Pack.zip` | `Hostwright_Agent_Arsenal_MD_Pack.zip` |

## Phase 5: Regenerate references

After rename, regenerate or update:

1. README.md
2. AGENTS.md
3. CLAUDE.md
4. CODEX.md
5. SECURITY.md
6. GOVERNANCE.md
7. docs/PROJECT_CHARTER.md
8. docs/reference/cli.md
9. docs/reference/hostwright-yaml.md
10. examples/*/hostwright.yaml
11. schemas/hostwright-yaml.schema.json
12. Package.swift module names
13. launchd label examples
14. install scripts
15. GitHub Actions workflow names

## Phase 6: Rename validation commands

Run these before merging the rename branch:

```bash
grep -R "Orchard\|orchard\|orchardd\|orchard.yaml\|orchard.cc" . \
  --exclude-dir=.git \
  --exclude="RENAME_PLAYBOOK.md" \
  --exclude="COLLISION_CHECK_LOG.md"

swift test
swift build
```

No old public terms should remain except in historical/changelog sections that explicitly explain the pre-development codename.

## Phase 7: Merge condition

Merge only when:

- the final name has passed ownership checks;
- all canonical terms are consistent;
- tests pass;
- docs render;
- old Orchard references are absent from public-facing docs;
- one human has reviewed runtime, security, and network references for accidental semantic changes.

