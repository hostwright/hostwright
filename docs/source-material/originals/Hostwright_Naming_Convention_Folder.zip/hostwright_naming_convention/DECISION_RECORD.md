# Naming Decision Record

## Decision

Hostwright is selected as the public-name candidate for the project formerly codenamed Orchard.

## Status

Pre-screened. Not yet canonical.

## Why Orchard is blocked

OpenAI has a public repository named `openai/orchard` for Apple Silicon VM orchestration. Because this project is also in the Apple Silicon orchestration/control-plane neighborhood, Orchard creates direct name, CLI, search, and credibility collision risk.

## Why Hostwright

Hostwright is a compound systems name. It avoids botanical, shipping, Kubernetes, Docker, and single-ancient-office naming collisions. It is serious enough for infrastructure, understandable enough for a CLI, and maps to the product's role: shaping and maintaining desired host state.

## Acceptance criteria before canonical rename

Hostwright becomes canonical only when:

1. GitHub repo/org path is reserved or chosen.
2. At least one clean domain is acquired or confirmed under user control.
3. User approves the final name.
4. The rename playbook is executed once on a dedicated branch.

