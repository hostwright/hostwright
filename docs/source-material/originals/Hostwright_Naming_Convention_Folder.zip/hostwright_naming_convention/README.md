# Hostwright Naming Convention Folder

This folder does not rename the existing Orchard research files. It defines the controlled naming convention and the exact steps to follow before any repository, documentation, CLI, daemon, manifest, package, or domain rename happens.

## Selected public candidate

| Field | Value |
|---|---|
| Candidate project name | Hostwright |
| CLI command | `hostwright` |
| Daemon | `hostwrightd` |
| Manifest file | `hostwright.yaml` |
| Preferred docs domain | `hostwright.dev` |
| Backup docs domains | `hostwright.sh`, `hostwright.io`, `hostwright.cc` |
| Repo target | `github.com/<org>/hostwright` |
| Package identity | `hostwright` |

## Current rule

Do not mass-rename the old Orchard documents yet. Treat Orchard as an internal historical codename only. Use Hostwright as the public-name candidate once GitHub and domain ownership are secured.

## Folder purpose

This folder gives agents and humans a single naming contract:

1. What the project should be called publicly.
2. What command names and file names should be used.
3. Which old names are forbidden.
4. Which checks must pass before rename.
5. How to execute the rename once, cleanly, without repeated churn.

