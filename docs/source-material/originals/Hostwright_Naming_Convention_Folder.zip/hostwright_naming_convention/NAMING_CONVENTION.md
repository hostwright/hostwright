# Naming Convention

## Public identity

The public project name is **Hostwright**, pending final ownership of the GitHub namespace and at least one clean domain.

Hostwright means a builder/craftsperson of the local host. The name fits a Mac-native desired-state control plane because the system shapes, repairs, supervises, and maintains host-local container workload state.

## Canonical terms

| Concept | Canonical name |
|---|---|
| Project | Hostwright |
| CLI | `hostwright` |
| Daemon | `hostwrightd` |
| Manifest | `hostwright.yaml` |
| Config directory | `~/.hostwright/` |
| State directory | `~/Library/Application Support/Hostwright/` |
| Log subsystem | `com.hostwright` |
| Launchd label | `com.hostwright.daemon` |
| Runtime adapter module | `HostwrightRuntime` |
| Core module | `HostwrightCore` |
| Reconciler module | `HostwrightReconciler` |
| State module | `HostwrightState` |
| CLI module | `HostwrightCLI` |
| Daemon module | `HostwrightDaemon` |
| YAML schema | `hostwright-yaml.schema.json` |
| Example stack | `examples/api-postgres/hostwright.yaml` |

## Command examples

```bash
hostwright init
hostwright apply
hostwright status
hostwright logs
hostwright restart
hostwright down
hostwright doctor
```

## Daemon examples

```bash
hostwrightd --config ~/.hostwright/config.yaml
launchctl print gui/$UID/com.hostwright.daemon
```

## Manifest example

```yaml
apiVersion: hostwright.dev/v1alpha1
kind: Stack
metadata:
  name: api-postgres
services:
  api:
    image: ghcr.io/example/api@sha256:...
    ports:
      - "8080:8080"
```

## Forbidden public terms

| Forbidden term | Reason |
|---|---|
| Orchard | OpenAI has `openai/orchard`, an Apple Silicon VM orchestration project. |
| `orchard` | CLI collision risk with OpenAI Orchard. |
| `orchardd` | Carries the blocked public name. |
| `orchard.yaml` | Carries the blocked public name. |
| orchard.cc | Carries the blocked public name. |

## Naming style rules

1. Use **Hostwright** for the human-facing project name.
2. Use lowercase `hostwright` for CLI, packages, folders, config files, and binary names.
3. Use `hostwrightd` for the daemon only.
4. Use `hostwright.yaml` for workload manifests.
5. Use `Hostwright*` PascalCase for Swift modules and types.
6. Do not introduce alternate names such as hwctl, hwd, hwyaml, hostctl, or hostd unless an ADR approves them.
7. Keep public docs, repo files, package metadata, examples, and screenshots consistent.
8. Do not use botanical names as replacements. The Orchard collision killed that naming lane.

